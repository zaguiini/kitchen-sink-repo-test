<?php
/**
 * Plugin Name: Plugin Revision 1
 */

echo 'Revision 1 plugin';
