<?php

echo 'Private submodule MU plugin';
