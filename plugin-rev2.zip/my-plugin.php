<?php
/**
 * Plugin Name: Plugin Revision 2
 */

echo 'Revision 2 plugin';
