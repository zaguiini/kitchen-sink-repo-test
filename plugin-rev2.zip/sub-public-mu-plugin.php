<?php

echo 'Public submodule MU plugin';
